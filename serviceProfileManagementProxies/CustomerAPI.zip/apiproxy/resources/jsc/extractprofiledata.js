var json = JSON.parse(context.getVariable("calloutResponse").content);
var apiproxy = context.getVariable("apiproxy.name");

//Authentication Profile
var evalpath = "$.entities[0].APIProxy[?(@.Name=='"+apiproxy+"')].Authentication";
var result = jsonPath(json,evalpath);
context.setVariable("profile.authentication", result);

//CommonPolicies Profile
var evalpath = "$.entities[0].APIProxy[?(@.Name=='"+apiproxy+"')].CommonPolicies";
var result = jsonPath(json,evalpath);
context.setVariable("profile.commonpolicies",result);

//Resources Profile
var evalpath = "$.entities[0].APIProxy[?(@.Name=='"+apiproxy+"')].Resources";
var result = jsonPath(json,evalpath);
context.setVariable("profile.resources",result);

//QuotaTimeUnit Profile
var result = jsonPath(json,"$.entities[0].QuotaTimeUnit");
context.setVariable("profile.quota.timeunit", JSON.stringify(result));

//QuotaTimeUnit QuotaValue
var result = jsonPath(json,"$.entities[0].QuotaValue");
context.setVariable("profile.quota.value", JSON.stringify(result));
