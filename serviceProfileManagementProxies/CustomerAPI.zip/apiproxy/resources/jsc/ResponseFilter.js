var myresponse = response.content.asJSON;
var visiblefields = context.getVariable("visiblefields");
var filteredresponse = stripKeys(myresponse,visiblefields);
response.content = JSON.stringify(filteredresponse);
