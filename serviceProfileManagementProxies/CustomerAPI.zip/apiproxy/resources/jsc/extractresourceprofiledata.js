//.replace(/[$-\/?[-^{|}]/g, '\\$&');
var resourcesprofile = context.getVariable("profile.resources");
var flowname = context.getVariable("current.flow.name")
var evalpath = "$.[?(@.name=='"+flowname+"')]";
var flowprofile = jsonPath(resourcesprofile,evalpath);
var accesscontrol_verbs_allow = true;
//Load visiblefields
var visiblefields = getKeys(flowprofile,'Visible')
context.setVariable("visiblefields", visiblefields);
context.setVariable("visiblefieldsString", JSON.stringify(visiblefields));

//Load resource metadata
var allowedVerbs = JSON.stringify(getValues(flowprofile,'verbs'));
context.setVariable("allowedVerbs", allowedVerbs);

if (allowedVerbs.indexOf(request.method)== -1) {
    accesscontrol_verbs_allow = false;
    context.setVariable("error_message", "You dont have the permissions to access this resource or method");
}
context.setVariable("accesscontrol_verbs_allow", accesscontrol_verbs_allow);

