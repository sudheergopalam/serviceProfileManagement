var commonpoliciesprofile = context.getVariable("profile.commonpolicies");

//Load Common Policies schema
context.setVariable("commonpoliciesprofile", JSON.stringify(commonpoliciesprofile));

//Load resource metadata
var enabled_CommonPolicies = JSON.stringify(getKeys(commonpoliciesprofile,'True'));
context.setVariable("enabled_CommonPolicies", enabled_CommonPolicies);

SpikeArrest = false;
if (enabled_CommonPolicies.indexOf(SpikeArrest)) {
    SpikeArrest = true;
}
context.setVariable("SpikeArrest", SpikeArrest);

