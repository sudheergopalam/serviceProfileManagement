var grant_type = context.getVariable("grant_type");
var scopes = context.getVariable("scope");
var allowed_scopes = context.getVariable("allowed_scopes");
var allowed_oAuthGrantTypes = context.getVariable("allowed_oAuthGrantTypes");
var authenticated = false;
//context.setVariable("authenticated", false);

//For simplicity of POC as long as any one scope check passes its consider authenticated
var scopes_array = scopes.split(' '); 
for each (var scope in  scopes_array)
{
    if (allowed_scopes.indexOf(scope)) {
        authenticated = true;
    }
    break;
}
if (!authenticated)
{
    context.setVariable("error_message", "Insufficient permissions on scopes");
}

if (allowed_oAuthGrantTypes.indexOf(grant_type)==-1) {
    authenticated = false;
    context.setVariable("error_message", "Insufficient permissions on grant_type");
}
context.setVariable("authenticated", authenticated);
