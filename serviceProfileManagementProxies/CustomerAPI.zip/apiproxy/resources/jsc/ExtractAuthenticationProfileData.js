var authenticationprofile = context.getVariable("profile.authentication");

//Load Authentication schemes
context.setVariable("authenticationprofile", JSON.stringify(authenticationprofile));

//Load resource metadata
var allowed_oAuthGrantTypes = JSON.stringify(getKeys(authenticationprofile,'True'));
context.setVariable("allowed_oAuthGrantTypes", allowed_oAuthGrantTypes);

var allowed_scopes = JSON.stringify(getValues(authenticationprofile,'Scopes'));
//var allowed_scopes_string = "Read";
context.setVariable("allowed_scopes", allowed_scopes);


